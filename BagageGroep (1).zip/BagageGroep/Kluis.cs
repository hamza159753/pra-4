using System;

namespace BagageGroep;

public class Kluis
{
    public string Code { get; set; }
    public string Password { get; set; }
}
